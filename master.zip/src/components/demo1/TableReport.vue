<template>
  <div>
    <el-table :data="tableData" stripe style="width: 100%"   height="45vh">
      <el-table-column prop="date" label="项目名称-资产"></el-table-column>
      <el-table-column prop="name" label="项目金额"></el-table-column>
      <el-table-column prop="address" label="项目名称-负债"></el-table-column>
      <el-table-column prop="xmje" label="项目金额"></el-table-column>
    </el-table>
  </div>
</template>
<script>
export default {
  data() {
    return {
      tableData: [
        {
          date: "货币资金",
          name: "35552",
          xmje: "12312",
          address: "短期借款"
        },
           {
          date: "货币资金",
          name: "35552",
          xmje: "12312",
          address: "短期借款"
        },   {
          date: "货币资金",
          name: "35552",
          xmje: "12312",
          address: "短期借款"
        },   {
          date: "货币资金",
          name: "35552",
          xmje: "12312",
          address: "短期借款"
        },   {
          date: "货币资金",
          name: "35552",
          xmje: "12312",
          address: "短期借款"
        },   {
          date: "货币资金",
          name: "35552",
          xmje: "12312",
          address: "短期借款"
        },   {
          date: "货币资金",
          name: "35552",
          xmje: "12312",
          address: "短期借款"
        },   {
          date: "货币资金",
          name: "35552",
          xmje: "12312",
          address: "短期借款"
        },   {
          date: "货币资金",
          name: "35552",
          xmje: "12312",
          address: "短期借款"
        },   {
          date: "货币资金",
          name: "35552",
          xmje: "12312",
          address: "短期借款"
        },   {
          date: "货币资金",
          name: "35552",
          xmje: "12312",
          address: "短期借款"
        },   {
          date: "货币资金",
          name: "35552",
          xmje: "12312",
          address: "短期借款"
        },   {
          date: "货币资金",
          name: "35552",
          xmje: "12312",
          address: "短期借款"
        },   {
          date: "货币资金",
          name: "35552",
          xmje: "12312",
          address: "短期借款"
        },   {
          date: "货币资金",
          name: "35552",
          xmje: "12312",
          address: "短期借款"
        },   {
          date: "货币资金",
          name: "35552",
          xmje: "12312",
          address: "短期借款"
        },   {
          date: "货币资金",
          name: "35552",
          xmje: "12312",
          address: "短期借款"
        },
      ]
    };
  },
  mounted() {},
  methods: {},
  components: {}
};
</script>

<style scoped>
</style>
