<template>
  <div id="myChart1" :style="{width: '100%', height: '35vh',padding:'0 0 0 0'}"></div>
</template>

<script>
export default {
  data() {
    return {};
  },

  mounted() {
    this.drawLine();
  },
  methods: {
    drawLine() {
      // 基于准备好的dom，初始化echarts实例
      let myChart = this.$echarts.init(document.getElementById("myChart1"));
      // 绘制图表
      var _this = this;
      let option = {
        title: {
          text: "订单完成率排名",
          // subtext: "<a href='./'>查看详情</a>",

          x: "center"
        },
        tooltip: {
          trigger: "axis"
        },
        legend: {
          data: ["移动", "联通", "电信"],
          y: "bottom"
        },
        grid: {
          left: "3%",
          right: "4%",
          // bottom: "3%",
          containLabel: true
        },

        xAxis: {
          type: "category",
          boundaryGap: false,
          data: ["北京", "河北", "内蒙古"],
          position: "top"
        },
        yAxis: {
          type: "value",
          max: "31"
        },
        series: [
          {
            name: "移动",
            type: "line",
            // stack: "总量",
            data: [10, 18, 11],
            itemStyle: { normal: { label: { show: true } } }
          },
          {
            name: "联通",
            type: "line",
            // stack: "总量",
            data: [5, 9, 6],
            itemStyle: { normal: { label: { show: true } } }
          },
          {
            name: "电信",
            type: "line",
            // stack: "总量",
            data: [15, 3, 2],
            itemStyle: { normal: { label: { show: true } } }
          }
        ]
      };

      myChart.setOption(option);
      // myChart.on("click", function(params) {
      //   debugger;
      // });
      myChart.on("click", function(params) {
        debugger;
        //监听地图点击事件
        _this.$router.push({ path: "/SaleHomePage2" });
      });
    }
  }
};
</script>

<style scoped>
</style>
