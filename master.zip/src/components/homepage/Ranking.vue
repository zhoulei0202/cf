<template>
  <div>
    <el-row>
      <el-col :span="24">综合排名</el-col>
    </el-row>
    <el-row>
      <el-col :span="10">订单完成率：</el-col>
      <el-col :span="10">
        <span class="rank blue">9</span>
        <i class="el-icon-bottom icon bottom-color"></i>
        <span class="bottom-color rank-size">2</span>
      </el-col>
    </el-row>
    <el-row>
      <el-col :span="10">回款完成率：</el-col>
      <el-col :span="10">
        <span class="rank red">10</span>
        <i class="el-icon-top icon top-color"></i>
        <span class="top-color rank-size">3</span>
      </el-col>
    </el-row>
  </div>
</template>
<script>
export default {
  data() {
    return {
      todoList: [
        {
          id: 1,
          value: "今天为您分配的新建潜在客户",
          label: "Swich(Sample)andy"
        }
      ]
    };
  },
  mounted() {},
  methods: {}
};
</script>

<style scoped>
.el-row {
  text-align: left;
  height: 6vh;
  line-height: 6vh;
  margin: 5px 0 5px 20px;
  font-weight: bold;
  font-size: 1.5em;
}
.rank {
  font-size: 1.8em;
  display: inline-block;
  width: 1.5em;
  text-align: center;
}
.blue {
  color: #1db6f0;
}
.red {
  color: #ff0000;
}
.icon {
  font-size: 1.8em;
  font-weight: 800;
}

.top-color {
  color: #ff0000;
}
.bottom-color {
  color: #92d050;
}
.rank-size{
  font-size: 1.2em;

}
</style>
