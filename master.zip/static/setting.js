// const importUrl = "http://localhost:7091/querySummaryDataSalesStatements";
// const importUrl = "http://10.100.128.228:8082/salesReport/querySummaryDataSalesStatements";
const importUrl = "/salesReport/querySummaryDataSalesStatements";

export default  { importUrl }